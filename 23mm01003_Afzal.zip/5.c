#include <stdio.h>

int main(){
int a = 2;



printf("%d",(a & 0));

return 0;
}
 
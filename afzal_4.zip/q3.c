#include<stdio.h>
int main(){
int credit;
int balance;

printf("enter a credit score and then Balance");
scanf("%d%d",&credit,&balance);

if(credit<=600){
    printf("interest rates is %f", ((float)balance*0.15));


}
else if(credit<=750){
    printf("interest rates is %f", ((float)balance*0.12));
}
else{
    printf("interest rates is %f", ((float)balance*0.10));
}

    return 0;
}
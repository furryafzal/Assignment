#include<stdio.h>

int main(){
    int number,count=0,divisor;
    printf("Enter a number and divisor ");
    scanf(" %d%d",&number,&divisor);
    while(number>=divisor){
    number = number-divisor;
    count++;
    }
    printf("\nquotient %d",count);
    printf("\nremainder %d",number);
    return 0;
}
#include<stdio.h>
int main(){
int number1;
int number2;
char operation;
printf("enter a number1 and number 2  and then the operator +,-,/,*\n");
scanf("%c",&operation);
scanf("%d%d",&number1,&number2);


switch (operation)
{
case '+':

    printf("%d", (number1 + number2));
    break;

case '-':
    printf("%d", (number1-number2));
    break;
case '/':
    if(!(number2 == 0)){
    printf("%d", (number1/number2));
    }
    else{
        printf("cant divide by zero");
    }
    break;
case '*':
    printf("%d", (number1*number2));
    break;

default:
    printf("invalid input");
    break;
}

    return 0;
}

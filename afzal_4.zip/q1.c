
#include<stdio.h>
int main(){
int num;
printf("eneter a number");
scanf("%d",&num);


switch (num%2)
{
case 0:
printf("given number is even");
    break;

case 1:
printf("given number is odd");
    break;

default:
    break;
}

    return 0;
}


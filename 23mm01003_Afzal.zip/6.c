#include <stdio.h>

int main(){
int a = 168;
int b;
b = a%2;

if(b==1&&(a>100)&&(a<200)){
printf("given number is odd and between 100 and 200");
}
else{
printf("\ngiven number doesnt satisfy the given conditions");
}
return 0;
}
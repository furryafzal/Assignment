#include<stdio.h>
#include<string.h>

#define MAX_STRING_LENGTH 50

int main() {
    int row, col;

    // Input number of rows and columns
    printf("Enter the number of rows: ");
    scanf("%d", &row);

    printf("Enter the number of columns: ");
    scanf("%d", &col);

    char matrix[row][col][MAX_STRING_LENGTH], transpose[col][row][MAX_STRING_LENGTH];

    // Input elements into the matrix
    printf("Enter the elements of the matrix:\n");
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            printf("Enter element at position (%d, %d): ", i + 1, j + 1);
            scanf("%s", matrix[i][j]);
        }
    }

    // Transpose the matrix
    for (int i = 0; i < col; i++) {
        for (int j = 0; j < row; j++) {
            strcpy(transpose[i][j], matrix[j][i]);
        }
    }

    // Display the original matrix
    printf("\nOriginal Matrix:\n");
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            printf("%s\t", matrix[i][j]);
        }
        printf("\n");
    }

    // Display the transposed matrix
    printf("\nTransposed Matrix:\n");
    for (int i = 0; i < col; i++) {
        for (int j = 0; j < row; j++) {
            printf("%s\t", transpose[i][j]);
        }
        printf("\n");
    }

    return 0;
}

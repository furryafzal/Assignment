#include <stdio.h>
#include <stdbool.h>
struct CourseRecord {
    char firstName[50];
    char lastName[50];
    int rollNumber;
    char department[50];
    char courseCode[20];
    int testMarks[3];
};

float calculateAverageTestMarks(struct CourseRecord cr) {
    float sum = 0;
    for (int i = 0; i < 3; i++) {
        sum += cr.testMarks[i];
    }
    return sum / 3;
}

bool isPass(struct CourseRecord cr) {
    float averageMarks = calculateAverageTestMarks(cr);
    if (averageMarks >= 35) {
        return true;
    } else {
        return false;
    }
}

int main() {
    struct CourseRecord student;
    printf("Enter student's first name: ");
    scanf("%s", student.firstName);

    printf("Enter student's last name: ");
    scanf("%s", student.lastName);

    printf("Enter student's roll number: ");
    scanf("%d", &student.rollNumber);

    printf("Enter department: ");
    scanf("%s", student.department);

    printf("Enter course code: ");
    scanf("%s", student.courseCode);

    printf("Enter test marks for 3 tests: ");
    for (int i = 0; i < 3; i++) {
        scanf("%d", &student.testMarks[i]);
    }
    printf("\nStudent's Details:\n");
    printf("Name: %s %s\n", student.firstName, student.lastName);
    printf("Roll Number: %d\n", student.rollNumber);
    printf("Department: %s\n", student.department);
    printf("Course Code: %s\n", student.courseCode);

    printf("Average Test Marks: %.2f\n", calculateAverageTestMarks(student));

    if (isPass(student)) {
        printf("Result: Pass\n");
    } else {
        printf("Result: Fail\n");
    }

    return 0;
}

#include<stdio.h>
int main(){
int num;
int sum;
int copyofnum;
printf("enter a number");
scanf("%d",&num);

if(num<100 || num>999){
    printf("invalid input");
    return 0;
}
for(int a = 0;a<=2;a++){
    sum = sum + ((num%10)*(num%10)*(num%10));
    num = num/10;

}
if(copyofnum == copyofnum){
    printf("armstrong number");
}
else{
    printf("not a armstrong number");
}

    return 0;
}

#include<stdio.h>
#include<string.h>

int main()
{
    int l;
    char A[100],B[100];
    char a[100],b[100],c[100];
    printf("\n Enter the string : ");
    scanf("%s",A);
    l=strlen(A);
        for(int j=0;j<3;j++)
        {
            a[j]=A[j];
            b[j]=A[j+3];
            c[j]=A[j+6];
        }
    a=strrev(a);
    b=strrev(b);
    c=strrev(c);
    B=strcon(c,b,a);
    printf("%s",B);

    return 0;

}
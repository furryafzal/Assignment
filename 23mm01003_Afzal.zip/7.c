#include <stdio.h>
#include<math.h>

int main(){
int a = 47;

a = round( a + (a*0.15) + (a*0.08));

printf("total cost of meal is %d",a);
return 0;
}
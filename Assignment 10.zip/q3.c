#include <stdio.h>
#include <string.h>

union EmpDetails {
    float hourlyWage;
    double fixedSalary;
};

struct Employee {
    int empID;
    char empName[50];
    union EmpDetails empDetails;
};

int main() {
    struct Employee emp;

    printf("Enter the employee id : ");
    scanf("%d",&emp.empID);
    printf("\nEnter the Name of the employee : ");
    scanf("%s",emp.empName);
    printf("\n Enter the hourly wage : ");
    scanf("%f",&emp.empDetails.hourlyWage);
    printf("\n Enter the fixed salary : ");
    scanf("%f",&emp.empDetails.fixedSalary);

    printf("Employee ID: %d\n", emp.empID);
    printf("Employee Name: %s\n", emp.empName);
    printf("Hourly Wage: %.2f\n", emp.empDetails.hourlyWage);
    printf("Fixed salary : %.2f\n", emp.empDetails.fixedSalary);

    return 0;
}

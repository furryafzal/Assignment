#include <stdio.h>
#include <string.h>

union Packet {
    struct {
        int opcode;
        int statusCode;
    } controlMessage;
    char dataPayload[100];
};

enum PacketType {
    CONTROL,
    DATA
};

struct DataPacket {
    enum PacketType packetType;
    union Packet packet;
};

void printControlMessage(union Packet packet) {
    printf("Control Message:\n");
    printf("Opcode: %d\n", packet.controlMessage.opcode);
    printf("Status Code: %d\n", packet.controlMessage.statusCode);
}

void printDataPayload(union Packet packet) {
    printf("Data Payload:\n");
    printf("%s\n", packet.dataPayload);
}

void printDataPacket(struct DataPacket dataPacket) {
    if (dataPacket.packetType == CONTROL) {
        printControlMessage(dataPacket.packet);
    } else {
        printDataPayload(dataPacket.packet);
    }
}

int main() {
    struct DataPacket packets[2];

    packets[0].packetType = CONTROL;
    packets[0].packet.controlMessage.opcode = 1;
    packets[0].packet.controlMessage.statusCode = 200;
    packets[1].packetType = DATA;
    strcpy(packets[1].packet.dataPayload, "Hello, world!");

    printf("Packet 1:\n");
    printDataPacket(packets[0]);
    printf("\nPacket 2:\n");
    printDataPacket(packets[1]);

    return 0;
}

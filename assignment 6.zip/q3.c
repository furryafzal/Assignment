#include<stdio.h>
int main()
{
    int n[10],m,b[10];
    printf("\n Enter the number of element : ");
    scanf("%d",&m);
    for(int i=0;i<m;i++)
    {
        printf("\n Enter the value of array : ");
        scanf("%d",&n[i]);
    }
    for(int j=0;j<m;j++)
    {
        b[j]=n[m-j-1];
    }
    for(int i=0;i<m;i++)
    {
        printf("%d, ",b[i]);
    }
}
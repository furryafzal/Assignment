#include <stdio.h>

int main(){
int a = 366;
int b;
b = a%365;
a = (int)a/365;

printf("years = %d",a);
a = b%30;
b = (int)b/365;
printf("\nmonths = %d",b);
b = a%7;
a = (int)a/365;
printf("\nweeks = %d",a);

printf("\ndays = %d",b);

return 0;
}
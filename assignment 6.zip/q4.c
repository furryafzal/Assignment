#include<stdio.h>
int main()
{
    int arr1[10],arr2[10],m,n,count=0;
    printf("\n Enter the number of element in array 1 : ");
    scanf("%d",&m);
    printf("\n Enter the no of element of array 2 : ");
    scanf("%d",&n);
    for(int i=0;i<m;i++)
    {   
        printf("\n enter the element of the array 1 : ");
        scanf("%d",&arr1[i]);
    }
    for(int i=0;i<n;i++)
    {   
        printf("\n enter the element of the array 2 : ");
        scanf("%d",&arr2[i]);
    }
    if(m>=n){
    for(int i =0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
             if (arr1[i]==arr2[j])
             {count++;
                /* code */
             }
        }
    }
    if(count==n)
    printf("\n the arr2 is a subset of arr1");
    else
    printf("\n arr2 is not a subset of arr1");
    }
    if(m<=n){
    for(int i =0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
             if (arr1[j]==arr2[i])
             {count++;
                /* code */
             }
        }
    }
    
    if(count==m)
    printf("\n the arr1 is a subset of arr2");
    else
    printf("\n arr1 is not a subset of arr2");
    }
    return 0;

}


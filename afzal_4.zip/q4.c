#include<stdio.h>
int main(){
int number;
printf("enter a number of day of week");
scanf("%d",&number);


switch (number)
{
case 1:
    printf("weekday is monday");
    break;

case 2:
    printf("weekday is tuesday");
    break;
case 3:
    printf("weekday is wednesday");
    break;
case 4:
    printf("weekday is thursday");
    break;
case 5:
    printf("weekday is friday");
    break;
case 6:
    printf("weekday is saturday");
    break;
case 7:
    printf("weekday is sunday");
    break;

default:
    printf("invalid input");
    break;
}

    return 0;
}

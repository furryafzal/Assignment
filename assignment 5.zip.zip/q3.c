#include <stdio.h>
int main(){
    int number;
    scanf("%d",&number);
    int digits[4];
    int sum=0;
    for(int i=0; i<=3;i++){
        digits[i]=(number%10);
        number = number/10;

    }

    for(int a=0; (a<=3);a++){
        if(digits[a]==0)continue;
        for(int b=0;(b<=3);b++){
            if(b==a)continue;
            for(int c=0;(c<=3);c++){
                if((c==a)||(c==b))continue; 
                for(int d=0;(d<=3);d++){
                    if((d==a)||(d==b)||(d==c))continue;
                    sum=(digits[a]*1000)+(digits[b]*100)+(digits[c]*10)+(digits[d]);
                    printf("%d\n", sum);
            }
                
            }
        }
    }
    
    return 0;
}

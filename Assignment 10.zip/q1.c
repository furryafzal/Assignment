#include <stdio.h>

union Data {
    int intValue;
    float floatValue;
    char charValue;
};
int main() {

    union Data data;
    printf("\n Enter the integer value :");
    scanf("%d",&data.intValue);
    printf("\n Enter the float value : ");
    scanf("%f",&data.floatValue);
    printf("\n Enter the character : ");
    scanf("%c",data.charValue);

    printf("Integer value: %d\n", data.intValue);
    printf("Float value: %.2f\n", data.floatValue);
    printf("Character value: %c\n", data.charValue);

    printf("\nAfter assigning values:\n");
    printf("Integer value: %d\n", data.intValue);
    printf("Float value: %.2f\n", data.floatValue);
    printf("Character value: %c\n", data.charValue);

    return 0;
}

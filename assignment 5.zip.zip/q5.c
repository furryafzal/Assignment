#include<stdio.h>
int main()
  {
  int broke=0;
  int number;
  char swich;
  int sum=0;
  while(broke==0){
    printf("provide number ");
    scanf("%d",&number);
    if(!(number%2)){
        sum = sum + number;
    }
    again:
    printf("\nwanna continue ");
    
    scanf("\n%c",&swich);
    switch (swich)
    {
    case 'n':
      
    case 'N':
      broke = 1;
      break;
    case 'y':
      
    case 'Y':
      break;
    
    default:
    printf("invalid input");
    goto again;
      break;
    }

    
    
  }
  
  printf("sum is %d",sum);
    
  return 0; 
  }
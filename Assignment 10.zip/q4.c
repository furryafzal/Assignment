#include <stdio.h>

#define MAX_SIZE 5
union ArrayUnion {
    int intArray[MAX_SIZE];
    float floatArray[MAX_SIZE];
    char charArray[MAX_SIZE];
};

int main() {
    union ArrayUnion arrUnion;

    for (int i = 0; i < MAX_SIZE; i++) {
        printf("\n Enter the elements of int array : ");
        scanf("%d",&arrUnion.intArray[i]);
    }
    printf("Integer Array:\n");
    for (int i = 0; i < MAX_SIZE; i++) {
        printf("%d ", arrUnion.intArray[i]);
    }
    printf("\n");

    for (int i = 0; i < MAX_SIZE; i++) {
       printf("\n Enter the elements of float array : ");
       scanf("%f",&arrUnion.floatArray[i]);
    }
    printf("Float Array:\n");
    for (int i = 0; i < MAX_SIZE; i++) {
        printf("%.2f ", arrUnion.floatArray[i]);
    }
    printf("\n");

    for (int i = 0; i < MAX_SIZE; i++) {
        printf("Enter the elements of char array : \n");
        scanf("%c",&arrUnion.charArray[i]);
    }

    printf("Character Array:\n");
    for (int i = 0; i < MAX_SIZE; i++) {
        printf("%c ", arrUnion.charArray[i]);
    }
    printf("\n");

    return 0;
}

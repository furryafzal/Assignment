#include <stdio.h>
#include <string.h>

enum PayType {
    HOURLY,
    SALARY
};

union EmpDetails {
    float hourlyWage;
    double fixedSalary;
};
struct Employee {
    int empID;
    char empName[50];
    enum PayType payType;
    union EmpDetails empDetails;
};

void printPayType(enum PayType payType) {
    if (payType == HOURLY) {
        printf("Pay Type: Hourly\n");
    } else {
        printf("Pay Type: Salary\n");
    }
}
void printEmployeeDetails(struct Employee emp) {
    printf("Employee ID: %d\n", emp.empID);
    printf("Employee Name: %s\n", emp.empName);
    printPayType(emp.payType);
    if (emp.payType == HOURLY) {
        printf("Hourly Wage: %.2f\n", emp.empDetails.hourlyWage);
    } else {
        printf("Fixed Salary: %.2f\n", emp.empDetails.fixedSalary);
    }
}

int main() {
    struct Employee emp;

    
    printf("Enter the employee id : ");
    scanf("%d",&emp.empID);
    printf("\nEnter the Name of the employee : ");
    scanf("%s",emp.empName);
    printf("\n Enter the hourly wage : ");
    scanf("%.2f",&emp.empDetails.hourlyWage);
    printf("\n Enter the fixed salary :");
    scanf("%lf",&emp.empDetails.fixedSalary);

    printf("Employee 1:\n");
    printEmployeeDetails(emp);

   
    printf("Enter the employee id : ");
    scanf("%d",&emp.empID);
    printf("\nEnter the Name of the employee : ");
    scanf("%s",emp.empName);
    printf("\n Enter the hourly wage : ");
    scanf("%.2f",&emp.empDetails.hourlyWage);
    printf("\n Enter the fixed salary :");
    scanf("%lf",&emp.empDetails.fixedSalary);
    
    printf("\nEmployee 2:\n");
    printEmployeeDetails(emp);

    return 0;
}

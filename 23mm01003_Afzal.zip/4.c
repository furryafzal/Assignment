#include <stdio.h>

int main(){
int a = 3000;

if((a%4)==0 && a%100 != 0 || a%400 == 0){
printf("given year is a leap year");
}
else{
printf("\ngiven year is not a leap year");
}
return 0;
}
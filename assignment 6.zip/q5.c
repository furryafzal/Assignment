#include<stdio.h>
#include<string.h>
#define MAX_STRING_LENGTH 50
int main()
{
    int r,c;

    printf("\n enter the no of rows : ");
    scanf("%d",&r);
    printf("\n Enter the no of columns : ");
    scanf("%d",&c);

    char A[r][c],B[c][r];
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            printf("Enter element at position (%d, %d): ", i + 1, j + 1);
            scanf("%s", A[i][j]);
        }
    }

    for(int i=0;i<c;i++)
    {
        for(int j=0;j<r;j++)
        {
            strcpy(B[i][j],A[j][i]);
        }
    }
    printf("\n Transpose matrix is:");
    for(int i=0;i<c;i++)
    {
        for(int j=0;j<r;j++)
        {
            printf("%s\t",B[i][j]);
        }
    printf("\n");
    }
    return 0; 
    
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct StudentRecord {
    char name[50];
    int rollNumber;
    float percentage;
};

struct Database {
    struct StudentRecord *records;
    int size;
};

void initializeDatabase(struct Database *db, int capacity) {
    db->records = (struct StudentRecord *)malloc(capacity * sizeof(struct StudentRecord));
    db->size = 0;
}

void insert(struct Database *db, struct StudentRecord newRecord) {
    if (db->size == 0 || newRecord.rollNumber > db->records[db->size - 1].rollNumber) {
        db->records[db->size] = newRecord;
    } else {
        int i = 0;
        while (i < db->size && newRecord.rollNumber > db->records[i].rollNumber) {
            i++;
        }
        for (int j = db->size; j > i; j--) {
            db->records[j] = db->records[j - 1];
        }
        db->records[i] = newRecord;
    }
    db->size++;
}

void displayDatabase(struct Database db) {
    printf("Student Records:\n");
    printf("Name\t\tRoll Number\tPercentage\n");
    for (int i = 0; i < db.size; i++) {
        printf("%s\t\t%d\t\t%.2f\n", db.records[i].name, db.records[i].rollNumber, db.records[i].percentage);
    }
}

void freeDatabase(struct Database *db) {
    free(db->records);
    db->size = 0;
}

int main() {
    struct Database db;
    int capacity, numRecords;
    
    printf("Enter capacity of the database: ");
    scanf("%d", &capacity);

    initializeDatabase(&db, capacity);

    printf("Enter number of records to insert: ");
    scanf("%d", &numRecords);

    for (int i = 0; i < numRecords; i++) {
        struct StudentRecord newRecord;
        printf("Enter details for record %d:\n", i + 1);
        printf("Name: ");
        scanf("%s", newRecord.name);
        printf("Roll Number: ");
        scanf("%d", &newRecord.rollNumber);
        printf("Percentage: ");
        scanf("%f", &newRecord.percentage);
        insert(&db, newRecord);
    }
    displayDatabase(db);
    freeDatabase(&db);

    return 0;
}

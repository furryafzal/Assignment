#include <stdio.h>
struct Address {
    char street[100];
    char city[50];
    char zipcode[6];
};
struct Person {
    char name[50];
    struct Address address;
};

int main() {
    struct Person person;

    printf("Enter person's name: ");
    scanf("%s", person.name);

    printf("Enter street: ");
    scanf("%s", person.address.street);

    printf("Enter city: ");
    scanf("%s", person.address.city);

    printf("Enter zipcode: ");
    scanf("%s", person.address.zipcode);

    printf("\nPerson's Details:\n");
    printf("Name: %s\n", person.name);
    printf("Address: %s, %s, %s .\n", person.address.street, person.address.city, person.address.zipcode);

    return 0;
}

#include<stdio.h>
int main()
{
    int i,n,r;
    int up ;
    printf("\n print the upper limit ");
    scanf("%d",&up);
    int low;
    printf("\n print the lower limit ");
    scanf("%d",&low);

    for(i=low;i<=up;i++)
    {
        int s=0;
        for(n=2;n<i;n++)
        {
            r=i%n;
        if(r==0)break;
        }
        if(r==0)continue;
        printf("%d,",i);

    }
    return 0;
}
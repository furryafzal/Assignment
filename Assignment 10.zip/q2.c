#include <stdio.h>

struct StructureData {
    int integer1;
    int integer2;
    char character;
};
union UnionData {
    int integer1;
    int integer2;
    char character;
};

int main() {
    printf("Size of StructureData: %lu bytes\n", sizeof(struct StructureData));

    printf("Size of UnionData: %lu bytes\n", sizeof(union UnionData));

    return 0;
}

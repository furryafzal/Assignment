int main(){
int age;


printf("enter age ");
scanf("%d",&age);

if(age<0){
    printf("invalid input");
}
else if(age<=5){
    printf("ticket price is free");


}
else if(age<=12){
    printf("ticket price is 20");
}
else if(age<=59){
    printf("ticket price is 50");
}
else {
    printf("ticket price is 40");
}


    return 0;
}
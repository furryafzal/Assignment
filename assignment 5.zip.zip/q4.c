#include<stdio.h>
int main()
  {
  int number;
    scanf("%d",&number);
    for(int i = 1;i<=number;i++){
        for(int a = 1;a <=(number-i);a++){
            printf(" ");

        }
        for(int b=1;b<=i;b++){
            printf(" *");
        }
        printf("\n");
    }
  return 0; 
  }
#include<stdio.h>

int main() {
    int city1[7], city2[7], city3[7], s=0,t=0,r=0;
    float avg1, avg2, avg3;


    for (int i = 0; i < 7; i++)
     {
        printf("\n Temperature of city 1 on day %d: ", i + 1);
        scanf("%d", &city1[i]);
    }

    for (int j = 0; j < 7; j++) 
    {
        printf("\n Temperature of city 2 on day %d: ", j + 1);
        scanf("%d", &city2[j]);
    }

    for (int i = 0; i < 7; i++)
     {
        printf("\n Temperature of city 3 on day %d: ", i + 1);
        scanf("%d", &city3[i]);
    }

    for (int i = 0; i < 7; i++) 
    {
        s = s + city1[i];
    }
    avg1 = (float)s / 7;
    printf("\n Average temperature in city 1 is %.2f", avg1);

    for (int i = 0; i < 7; i++) 
    {
        t = t + city2[i];
    }
    avg2 = (float)t / 7;
    printf("\n Average temperature in city 2 is %.2f", avg2);

    for (int i = 0; i < 7; i++)
    {
        r = r + city3[i];
    }
    avg3 = (float)r / 7;
    printf("\n Average temperature in city 3 is %.2f", avg3);

    return 0;
}

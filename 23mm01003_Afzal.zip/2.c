#include <stdio.h>

int main(){
int a = 50;
int b = 69;
int c = 42;

if(a>b && a>c){
printf("a is greatest");
}
else if (b>c)
{
  printf("b is greatest"); 
}
else{

printf("c is greatest");
}

return 0;
}
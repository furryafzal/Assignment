#include <stdio.h>
struct Date {
    int day;
    int month;
    int year;
};
int compareDates(struct Date date1, struct Date date2) 
{
    if (date1.year > date2.year)
        return 1;
    else if (date1.year < date2.year)
        return -1;
    if (date1.month > date2.month)
        return 1;
    else if (date1.month < date2.month)
        return -1;
    if (date1.day > date2.day)
        return 1;
    else if (date1.day < date2.day)
        return -1;
    return 0;
}

int main() 
{
    struct Date date1;
    struct Date date2;
    printf("enter the date 1 : ");
    scanf("%d%d%d",&date1.day,&date1.month,&date1.year);
    printf("enter the date 2 : ");
    scanf("%d%d%d",&date2.day,&date2.month,&date2.year);
    printf("Comparison result for date1 and date2: %d\n", compareDates(date1, date2));
    return 0;
}
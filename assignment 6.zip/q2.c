#include<stdio.h>
int main()
{
    int  i, n[10],avg,m,s=0;
    printf("\n Enter the no of elements in the array :");
    scanf("%d",&m);
    for(i=0;i<m;i++)
    {
        printf("\n Enter the values of input array :");
        scanf ("%d",&n[i]);
    }
    for(i=0;i<m;i++)
    {
        s=s+n[i];
    }
    avg=s/m;
    for(i=0;i<m;i++)
    {
        if(n[i]>=avg)
        printf("%d,",n[i]);
    }
    return 0;
}